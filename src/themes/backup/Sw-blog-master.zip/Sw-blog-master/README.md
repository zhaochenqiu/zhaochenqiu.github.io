

** Sw'blog Hexo 主题：**魔改自 [Hexo 主题：SPFK](http://luuman.github.io/categories/Hexo/)，

只是对部分代码做了修改，主要是做了主题透明，但是写死了（PS：我真不会前端....这块还是Process写的）

另外一方面添加了搜索框站内搜索，主要是对标题的搜索....

搜索框需要插件的。
```
## rss插件
npm install hexo-generator-feed --save

## 本地搜索插件集成
npm install hexo-generator-search --save
```
另外配置文件也得做一些修改，根目录下的 _config.yml
```
search:
  path: search.json
  field: post
```
主题下的 _config.yml
```
search_box: true
search:
  path: search.json
  field: post
```

![](demo.png)
和我的桌面毫无违和感。

这样就基本没什么问题了。。。

